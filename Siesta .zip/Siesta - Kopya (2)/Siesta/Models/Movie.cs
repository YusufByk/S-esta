﻿using System.Collections.Generic;

namespace Siesta.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ReleaseYear { get; set; }
        public string CoverImageUrl { get; set; }
        public List<Rating> Ratings { get; set; }
        public List<Comment> Comments { get; set; }
        public List<Watchlist> Watchlists { get; set; }
        public List<MovieGenre> MovieGenres { get; set; }
    }
}
