﻿using System.ComponentModel.DataAnnotations;

namespace Siesta.Models.ViewModels
{
    public class ProfileViewModel
    {
        public string UserName { get; set; }

        public string Email { get; set; }

        public string ProfileBio { get; set; }

        public string ProfilePictureUrl { get; set; }

        [Display(Name = "Yeni Kullanıcı Adı")]
        public string NewUserName { get; set; }

        [Required(ErrorMessage = "Mevcut şifre gerekli.")]
        [DataType(DataType.Password)]
        [Display(Name = "Mevcut Şifre")]
        public string CurrentPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Yeni Şifre")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Yeni şifre ile onay şifresi eşleşmiyor.")]
        [Display(Name = "Yeni Şifreyi Onayla")]
        public string ConfirmPassword { get; set; }
    }
}