﻿using System;

namespace Siesta.Models
{
    public class Follow
    {
        public string FollowerId { get; set; }
        public string FollowedId { get; set; }
        public DateTime FollowedAt { get; set; } = DateTime.UtcNow;

        // Navigasyon Özellikleri
        public ApplicationUser Follower { get; set; }
        public ApplicationUser Followed { get; set; }
    }
}