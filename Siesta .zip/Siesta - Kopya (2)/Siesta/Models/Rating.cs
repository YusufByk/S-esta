﻿using System;

namespace Siesta.Models
{
    public class Rating
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public int MovieId { get; set; }
        public int Score { get; set; } // Örneğin: 1-10 arası
        public DateTime RatedAt { get; set; } = DateTime.UtcNow;

        // Navigasyon Özellikleri
        public ApplicationUser User { get; set; }
        public Movie Movie { get; set; }
    }
}