﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace Siesta.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string ProfileBio { get; set; } // Nullable string
        public string ProfilePictureUrl { get; set; } // Nullable string
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public List<Rating> Ratings { get; set; }
        public List<Comment> Comments { get; set; }
        public List<Message> SentMessages { get; set; }
        public List<Message> ReceivedMessages { get; set; }
        public List<Watchlist> Watchlists { get; set; }
        public List<Follow> Followers { get; set; }
        public List<Follow> Following { get; set; }
    }
}