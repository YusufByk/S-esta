﻿using System.ComponentModel.DataAnnotations;

namespace Siesta.Models.ViewModels
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Kullanıcı adı gereklidir.")]
        [StringLength(50, ErrorMessage = "Kullanıcı adı en fazla 50 karakter olabilir.")]
        [RegularExpression(@"^[a-zA-Z0-9\s\-.@+]+$", ErrorMessage = "Kullanıcı adı yalnızca harf, rakam, boşluk ve -.@+ karakterlerini içerebilir.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "E-posta gereklidir.")]
        [EmailAddress(ErrorMessage = "Geçerli bir e-posta adresi girin.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Parola gereklidir.")]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "Parola en az {2} ve en fazla {1} karakter olmalı.", MinimumLength = 6)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Parolalar eşleşmiyor.")]
        public string ConfirmPassword { get; set; }
    }
}