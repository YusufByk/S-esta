﻿using System.ComponentModel.DataAnnotations;

namespace Siesta.Models.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "E-posta veya kullanıcı adı gereklidir.")]
        public string EmailOrUserName { get; set; }

        [Required(ErrorMessage = "Parola gereklidir.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool RememberMe { get; set; }
    }
}
