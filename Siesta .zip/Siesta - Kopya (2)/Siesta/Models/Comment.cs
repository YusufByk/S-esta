﻿using System;

namespace Siesta.Models
{
    public class Comment
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public int MovieId { get; set; }
        public string Content { get; set; }
        public DateTime CommentedAt { get; set; } = DateTime.UtcNow;

        // Navigasyon Özellikleri
        public ApplicationUser User { get; set; }
        public Movie Movie { get; set; }
    }
}