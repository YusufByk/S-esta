﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Siesta.Models;
using Siesta.Models.ViewModels;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Siesta.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ILogger<ProfileController> _logger;

        public ProfileController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            ILogger<ProfileController> logger)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        // Profil görüntüleme
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                _logger.LogInformation("Profil görüntüleme başlatılıyor: {UserId}", User.Identity.Name);
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    _logger.LogWarning("Kullanıcı bulunamadı: {UserId}", User.Identity.Name);
                    return NotFound("Kullanıcı bulunamadı.");
                }

                var model = new ProfileViewModel
                {
                    UserName = user.UserName,
                    Email = user.Email,
                    ProfileBio = user.ProfileBio,
                    ProfilePictureUrl = user.ProfilePictureUrl
                };

                _logger.LogInformation("Profil görüntüleme başarılı: {UserId}", user.Id);
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Profil görüntüleme sırasında hata oluştu: {Message}", ex.Message);
                return StatusCode(500, "Bir hata oluştu, lütfen tekrar deneyin.");
            }
        }

        // Profil düzenleme GET
        [HttpGet]
        public async Task<IActionResult> Edit()
        {
            try
            {
                _logger.LogInformation("Profil düzenleme formu yükleniyor: {UserId}", User.Identity.Name);
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    _logger.LogWarning("Kullanıcı bulunamadı: {UserId}", User.Identity.Name);
                    return NotFound("Kullanıcı bulunamadı.");
                }

                var model = new ProfileViewModel
                {
                    UserName = user.UserName,
                    Email = user.Email,
                    ProfileBio = user.ProfileBio,
                    ProfilePictureUrl = user.ProfilePictureUrl
                };

                _logger.LogInformation("Profil düzenleme formu yüklendi: {UserId}", user.Id);
                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Profil düzenleme formu yüklenirken hata oluştu: {Message}", ex.Message);
                return StatusCode(500, "Bir hata oluştu, lütfen tekrar deneyin.");
            }
        }

        // Profil düzenleme POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProfileViewModel model)
        {
            try
            {
                _logger.LogInformation("Profil düzenleme başlatılıyor: {UserId}, ProfileBio: {ProfileBio}, NewUserName: {NewUserName}",
                    User.Identity.Name, model.ProfileBio, model.NewUserName);

                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    _logger.LogWarning("Kullanıcı bulunamadı: {UserId}", User.Identity.Name);
                    return NotFound("Kullanıcı bulunamadı.");
                }

                // Doğrulama: Biyografi boş olamaz
                if (string.IsNullOrEmpty(model.ProfileBio))
                {
                    ModelState.AddModelError("ProfileBio", "Biyografi boş olamaz.");
                    _logger.LogWarning("Biyografi boş: {UserId}", User.Identity.Name);
                }

                // Doğrulama: Şifre değişikliği için mevcut şifre ve yeni şifre gerekli
                if (!string.IsNullOrEmpty(model.NewPassword))
                {
                    if (string.IsNullOrEmpty(model.CurrentPassword))
                    {
                        ModelState.AddModelError("CurrentPassword", "Mevcut şifre gerekli.");
                        _logger.LogWarning("Mevcut şifre boş: {UserId}", User.Identity.Name);
                    }
                    if (model.NewPassword != model.ConfirmPassword)
                    {
                        ModelState.AddModelError("ConfirmPassword", "Yeni şifre ile onay şifresi eşleşmiyor.");
                        _logger.LogWarning("Şifre onayı eşleşmedi: {UserId}", User.Identity.Name);
                    }
                }

                // ModelState’ten gereksiz alanları temizle
                ModelState.Remove("UserName");
                ModelState.Remove("Email");
                ModelState.Remove("ProfilePictureUrl");

                if (!ModelState.IsValid)
                {
                    _logger.LogWarning("ModelState geçersiz: {Errors}", string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
                    return View(model);
                }

                // Kullanıcı adını güncelle
                bool userNameChanged = false;
                if (!string.IsNullOrEmpty(model.NewUserName) && model.NewUserName != user.UserName)
                {
                    _logger.LogInformation("Kullanıcı adı güncelleniyor: {OldUserName} -> {NewUserName}", user.UserName, model.NewUserName);
                    var existingUser = await _userManager.FindByNameAsync(model.NewUserName);
                    if (existingUser != null)
                    {
                        ModelState.AddModelError("NewUserName", "Bu kullanıcı adı zaten alınmış.");
                        _logger.LogWarning("Kullanıcı adı zaten alınmış: {NewUserName}", model.NewUserName);
                        return View(model);
                    }
                    user.UserName = model.NewUserName;
                    userNameChanged = true;
                }

                // Profil biyografisini güncelle
                _logger.LogInformation("Biyografi güncelleniyor: {ProfileBio}", model.ProfileBio);
                user.ProfileBio = model.ProfileBio;

                // Kullanıcı bilgilerini güncelle
                _logger.LogInformation("Kullanıcı güncelleniyor: {UserId}", user.Id);
                var updateResult = await _userManager.UpdateAsync(user);
                if (!updateResult.Succeeded)
                {
                    foreach (var error in updateResult.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                        _logger.LogError("Identity hatası (kullanıcı güncelleme): {ErrorCode} - {ErrorDescription}", error.Code, error.Description);
                    }
                    return View(model);
                }

                // Şifreyi güncelle
                if (!string.IsNullOrEmpty(model.NewPassword))
                {
                    _logger.LogInformation("Şifre güncelleniyor: {UserId}", user.Id);
                    var changePasswordResult = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
                    if (!changePasswordResult.Succeeded)
                    {
                        foreach (var error in changePasswordResult.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                            _logger.LogError("Identity hatası (şifre güncelleme): {ErrorCode} - {ErrorDescription}", error.Code, error.Description);
                        }
                        return View(model);
                    }
                    userNameChanged = true; // Şifre değiştiğinde de oturumu yenile
                }

                // Kullanıcı adı veya şifre değiştiyse oturumu yenile
                if (userNameChanged)
                {
                    _logger.LogInformation("Oturum yenileniyor: {UserId}", user.Id);
                    await _signInManager.RefreshSignInAsync(user);
                }

                _logger.LogInformation("Profil başarıyla güncellendi: {UserId}", user.Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Profil güncelleme sırasında hata oluştu: {Message}", ex.Message);
                ModelState.AddModelError(string.Empty, "Bir hata oluştu, lütfen tekrar deneyin.");
                return View(model);
            }
        }
    }
}